package aquarium.entities.fish;

public class FreshwaterFish extends BaseFish {
    private final static int INITIAL_SIZE = 3;
    private final static int FISH_SIZE_INCREASER = 3;

    //Can only live in FreshwaterAquarium!

    public FreshwaterFish(String name, String species, double price) {
        super(name, species, price);
        setSize(INITIAL_SIZE);
    }

    @Override
    public void eat() {
        setSize(getSize() + FISH_SIZE_INCREASER);
    }
}
