package aquarium.entities.fish;

public class SaltwaterFish extends BaseFish {
    private final static int INITAL_SIZE = 5;
    private final static int FISH_SIZE_INCREASER = 2;

    //Can only live in SaltwaterAquarium!

    public SaltwaterFish(String name, String species, double price) {
        super(name, species, price);
        setSize(INITAL_SIZE);
    }

    @Override
    public void eat() {
        setSize(getSize() + FISH_SIZE_INCREASER);
    }
}
